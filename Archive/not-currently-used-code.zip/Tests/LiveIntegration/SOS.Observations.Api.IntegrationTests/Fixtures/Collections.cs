﻿namespace SOS.Observations.Api.LiveIntegrationTests.Fixtures
{
    public static class Collections
    {
        public const string ApiIntegrationTestsCollection = "ApiIntegrationTestsCollection";
    }
}
