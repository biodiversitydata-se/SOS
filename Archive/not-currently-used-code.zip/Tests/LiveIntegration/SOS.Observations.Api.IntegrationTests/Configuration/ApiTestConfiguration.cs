﻿namespace SOS.Observations.Api.LiveIntegrationTests.Configuration
{
    public class ApiTestConfiguration
    {
        public string ApiUrl { get; set; }
    }
}
