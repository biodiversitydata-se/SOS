﻿namespace SOS.UserStatistics.Api.IntegrationTests.Fixtures
{
    public static class Collections
    {
        public const string ApiIntegrationTestsCollection = "ApiIntegrationTestsCollection";        
    }
}
