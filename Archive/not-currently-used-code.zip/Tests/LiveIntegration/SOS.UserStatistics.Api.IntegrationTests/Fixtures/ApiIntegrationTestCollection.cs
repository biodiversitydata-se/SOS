﻿namespace SOS.UserStatistics.Api.IntegrationTests.Fixtures;

[CollectionDefinition(Collections.ApiIntegrationTestsCollection)]
public class ApiIntegrationTestCollection : ICollectionFixture<UserStatisticsIntegrationTestFixture>
{

}
