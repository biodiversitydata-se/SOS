﻿namespace SOS.UsersStatistics.Api.AutomaticIntegrationTests.Fixtures;

public static class Collections
{
    public const string ApiAutomaticIntegrationTestsCollection = "ApiAutomaticIntegrationTestsCollection";        
}
