﻿namespace SOS.UserStatistics.Api.AutomaticIntegrationTests.Fixtures;

[CollectionDefinition(Collections.ApiAutomaticIntegrationTestsCollection)]
public class ApiAutomaticIntegrationTestCollection : ICollectionFixture<UserStatisticsAutomaticIntegrationTestFixture>
{
}
