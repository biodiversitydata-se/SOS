﻿namespace SOS.UserStatistics.Api.AutomaticIntegrationTests.Helpers;

public enum InstallationEnvironment
{
    Unknown = 0,
    Local = 1,
    DevelopmentTest = 2,
    SystemTest = 3,
    Production = 4
}