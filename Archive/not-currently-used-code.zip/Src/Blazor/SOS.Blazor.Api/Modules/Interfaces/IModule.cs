﻿namespace SOS.Blazor.Api.Modules.Interfaces;

public interface IModule
{
    void MapEndpoints(WebApplication application);
}
