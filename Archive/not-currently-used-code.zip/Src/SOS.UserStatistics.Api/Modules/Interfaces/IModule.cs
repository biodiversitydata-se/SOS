﻿namespace SOS.UserStatistics.Modules.Interfaces;

interface IModule
{
    void MapEndpoints(WebApplication application);
}
