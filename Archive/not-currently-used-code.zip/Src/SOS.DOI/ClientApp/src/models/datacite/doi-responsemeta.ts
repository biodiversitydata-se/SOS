export interface IResponseMeta {
  total: number;
}
