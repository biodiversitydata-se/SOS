/**
 *
 */
export interface ICreator {
  name: string;
  nameType: string;
  givenName: string;
  familyName: string;
}

