/**
 *
 */
export interface ITitle {
  title: string;
}

