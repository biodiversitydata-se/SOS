import { IAttributes } from './doi-attributes';

export interface IMetadata {
  attributes: IAttributes;
  id: string;
  type: string;
}
