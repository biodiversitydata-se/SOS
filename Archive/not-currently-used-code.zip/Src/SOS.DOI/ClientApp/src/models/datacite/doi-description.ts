/**
 *
 */
export interface IDescription {
  description: string;
  descriptionType: string;
}
