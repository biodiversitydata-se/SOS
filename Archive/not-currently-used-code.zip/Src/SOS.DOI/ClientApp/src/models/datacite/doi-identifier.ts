/**
 *
 */
export interface IIdentifier {
  identifier: string;
  identifierType: string;
}
