import { Component } from '@angular/core';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.scss']
})
export class TopMenuComponent {
}
