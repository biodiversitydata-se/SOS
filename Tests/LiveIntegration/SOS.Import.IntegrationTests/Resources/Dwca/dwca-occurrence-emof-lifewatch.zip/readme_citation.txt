﻿In scientific publications and other reports that use the SLW Analysis Portal, the following citation should be used:

Material and methods
========================
Data in this study has been downloaded from the Swedish LifeWatch Analysis Portal (Leidenberger et al., 2016) on 2019-12-10.
The following databases have been used:
   - Artportalen
   - Shark SMHI
   - MVM
   - Musselportalen
   - Virtuella Herbariet

References
========================
Leidenberger S, Käck M, Karlsson B, Kindvall O (2016) The Analysis Portal and the Swedish LifeWatch e-infrastructure for biodiversity research. Biodiversity Data Journal 4: e7644. doi: 10.3897/BDJ.4.e7644

Acknowledgements
========================
We acknowledge Swedish LifeWatch (SLW) for provisioning of e-infrastructure tools and services. SLW is funded by the Swedish Research Council and the Swedish University of Agricultural Sciences (SLU) as a national research infrastructure (Grant No. 2017-00634).
